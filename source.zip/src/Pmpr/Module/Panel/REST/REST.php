<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a51215dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\REST; use Pmpr\Common\Foundation\REST\RESTRegister; class REST extends RESTRegister { public function gigwcakmiyayoigw() { $this->ogyceaekywowkqsc(WP::symcgieuakksimmu())->ogyceaekywowkqsc(Icon::symcgieuakksimmu())->ogyceaekywowkqsc(Auth::symcgieuakksimmu())->ogyceaekywowkqsc(Router::symcgieuakksimmu())->ogyceaekywowkqsc(Profile::symcgieuakksimmu())->ogyceaekywowkqsc(Setting::symcgieuakksimmu()); } }
