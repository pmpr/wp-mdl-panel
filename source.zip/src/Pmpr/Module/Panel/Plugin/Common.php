<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae91609d34             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin; use Pmpr\Module\Panel\Container; class Common extends Container { }
