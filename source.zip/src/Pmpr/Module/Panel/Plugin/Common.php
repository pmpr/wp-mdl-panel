<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec2f1d944             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin; use Pmpr\Module\Panel\Container; class Common extends Container { }
