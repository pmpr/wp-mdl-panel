<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec2f1d944             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\157\157\x63\x6f\x6d\x6d\145\162\x63\x65\137\162\145\163\164\137\x63\150\x65\143\x6b\137\160\x65\162\x6d\x69\163\x73\x69\x6f\156\x73", [$this, "\153\x6f\x65\151\155\x77\x65\x63\171\x69\x69\161\147\145\163\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\x65\x74\137\152\167\x74\x5f\x61\165\x74\x68\x5f\164\157\153\x65\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto csscmcacoikwsecs; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto asmecuqiyyswueqe; } $qoowakyqgwcscuss = true; asmecuqiyyswueqe: csscmcacoikwsecs: return $qoowakyqgwcscuss; } }
