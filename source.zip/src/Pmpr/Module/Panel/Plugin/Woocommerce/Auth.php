<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce9ac56a7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; use Pmpr\Module\Panel\Container; class Auth extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\157\157\x63\x6f\x6d\155\x65\162\143\145\137\162\x65\x73\x74\x5f\143\x68\x65\143\153\137\160\145\x72\155\151\163\x73\151\157\x6e\163", [$this, "\153\x6f\145\x69\155\167\x65\x63\171\x69\151\161\x67\x65\x73\x6b"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\x65\x74\137\x6a\167\x74\x5f\141\x75\x74\x68\x5f\164\157\153\x65\x6e", false); if ($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac)) { $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if ($mkucggyaiaukqoce) { $qoowakyqgwcscuss = true; } } return $qoowakyqgwcscuss; } }
