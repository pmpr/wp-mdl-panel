<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6795528f61d19             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; use Pmpr\Module\Panel\Container; class Auth extends Container { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\x63\157\x6d\x6d\x65\x72\x63\145\x5f\162\x65\x73\x74\x5f\143\x68\145\143\x6b\137\160\145\162\155\151\163\163\151\157\x6e\x73", [$this, "\x6b\157\145\x69\x6d\167\x65\143\x79\151\x69\x71\x67\145\x73\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\145\164\137\152\167\x74\137\141\x75\x74\x68\x5f\x74\x6f\153\x65\156", false); if ($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac)) { $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if ($mkucggyaiaukqoce) { $qoowakyqgwcscuss = true; } } return $qoowakyqgwcscuss; } }
