<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae91609d34             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\x63\x6f\155\x6d\145\162\143\145\x5f\x72\145\x73\164\x5f\143\x68\x65\x63\153\137\x70\x65\162\155\151\163\x73\x69\x6f\x6e\x73", [$this, "\x6b\157\145\x69\155\x77\x65\x63\171\x69\151\x71\x67\x65\163\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\145\x74\137\x6a\x77\164\137\141\x75\x74\x68\x5f\164\x6f\153\145\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto csscmcacoikwsecs; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto asmecuqiyyswueqe; } $qoowakyqgwcscuss = true; asmecuqiyyswueqe: csscmcacoikwsecs: return $qoowakyqgwcscuss; } }
