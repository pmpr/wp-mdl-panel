<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66810764202ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\x6f\143\x6f\x6d\155\x65\x72\x63\145\137\162\145\x73\164\x5f\x63\150\x65\143\x6b\137\x70\x65\162\x6d\x69\163\x73\x69\x6f\156\x73", [$this, "\x6b\157\145\151\155\167\x65\143\171\151\151\x71\147\145\163\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\x67\145\x74\x5f\152\167\164\137\x61\165\x74\x68\137\164\x6f\153\145\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto esikeyqyuikmaiek; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto iwsmmkqaoksmocok; } $qoowakyqgwcscuss = true; iwsmmkqaoksmocok: esikeyqyuikmaiek: return $qoowakyqgwcscuss; } }
