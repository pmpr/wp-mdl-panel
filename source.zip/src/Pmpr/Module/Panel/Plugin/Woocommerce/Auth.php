<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc183e80f5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\x63\x6f\x6d\155\145\x72\x63\145\x5f\162\x65\x73\164\137\x63\150\x65\x63\x6b\137\160\145\162\x6d\151\x73\163\151\x6f\156\163", [$this, "\153\157\145\x69\155\x77\x65\143\171\x69\x69\161\147\145\x73\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\145\164\137\x6a\167\164\x5f\x61\x75\x74\150\x5f\x74\x6f\153\145\156", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto qsygcycwieukkgwc; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto umgaesggesswoaqe; } $qoowakyqgwcscuss = true; umgaesggesswoaqe: qsygcycwieukkgwc: return $qoowakyqgwcscuss; } }
