<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870825de9a6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\157\157\x63\157\x6d\x6d\145\x72\x63\145\137\x72\145\x73\164\137\143\150\x65\x63\153\x5f\160\x65\162\x6d\x69\x73\163\x69\157\x6e\163", [$this, "\x6b\157\145\x69\x6d\x77\145\143\x79\x69\151\161\147\x65\x73\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\145\x74\x5f\x6a\167\x74\137\x61\x75\164\x68\x5f\x74\x6f\x6b\145\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto esikeyqyuikmaiek; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto iwsmmkqaoksmocok; } $qoowakyqgwcscuss = true; iwsmmkqaoksmocok: esikeyqyuikmaiek: return $qoowakyqgwcscuss; } }
