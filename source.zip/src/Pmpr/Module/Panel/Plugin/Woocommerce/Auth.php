<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400f0d869d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\x6f\x63\x6f\x6d\x6d\x65\x72\143\145\x5f\162\145\x73\164\137\143\x68\x65\x63\153\137\x70\x65\162\155\151\163\x73\151\x6f\x6e\x73", [$this, "\153\157\145\151\155\167\145\143\171\151\151\x71\x67\145\163\x6b"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\x67\145\164\137\x6a\167\x74\x5f\x61\x75\x74\150\137\x74\157\x6b\x65\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto esikeyqyuikmaiek; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto iwsmmkqaoksmocok; } $qoowakyqgwcscuss = true; iwsmmkqaoksmocok: esikeyqyuikmaiek: return $qoowakyqgwcscuss; } }
