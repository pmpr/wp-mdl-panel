<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a8141bb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\157\x6f\143\157\x6d\x6d\145\162\143\x65\137\162\x65\163\x74\137\143\x68\145\x63\153\137\160\145\x72\x6d\151\x73\163\x69\x6f\156\x73", [$this, "\x6b\157\x65\151\x6d\167\x65\143\171\x69\151\161\147\145\x73\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\145\164\137\x6a\167\x74\x5f\141\x75\x74\150\137\164\157\x6b\x65\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto wwukgaquuyoissgy; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto suqcsgaosywaauuu; } $qoowakyqgwcscuss = true; suqcsgaosywaauuu: wwukgaquuyoissgy: return $qoowakyqgwcscuss; } }
