<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a89c0e6c9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\157\x63\x6f\155\155\145\x72\x63\145\x5f\162\x65\x73\x74\x5f\x63\x68\x65\x63\153\x5f\160\x65\x72\x6d\151\163\163\x69\x6f\156\163", [$this, "\153\157\x65\151\155\167\145\143\171\151\x69\161\147\145\163\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\x65\x74\x5f\152\167\164\137\141\165\x74\150\137\164\157\x6b\145\156", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto igymseewwyiocoug; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto sukskmcwsoysiuqu; } $qoowakyqgwcscuss = true; sukskmcwsoysiuqu: igymseewwyiocoug: return $qoowakyqgwcscuss; } }
