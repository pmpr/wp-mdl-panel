<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66069841be735             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin\Woocommerce; class Auth extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\x6f\143\x6f\155\155\x65\x72\x63\x65\x5f\162\x65\163\164\x5f\143\x68\145\143\153\x5f\x70\x65\162\155\x69\x73\163\x69\157\156\x73", [$this, "\153\x6f\x65\151\x6d\167\145\143\171\151\x69\161\x67\x65\163\153"], 10, 4); parent::kgquecmsgcouyaya(); } public function koeimwecyiiqgesk($qoowakyqgwcscuss, $mgkceomocowocqyo, $aokagokqyuysuksm, $sqeykgyoooqysmca) : bool { $sogksuscggsicmac = $this->ocksiywmkyaqseou("\147\145\164\x5f\152\167\164\137\141\x75\164\x68\137\x74\157\153\x65\x6e", false); if (!($sogksuscggsicmac && !is_wp_error($sogksuscggsicmac))) { goto qsygcycwieukkgwc; } $mkucggyaiaukqoce = $this->caokeucsksukesyo()->issssuygyewuaswa()->get($this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, 2)); if (!$mkucggyaiaukqoce) { goto umgaesggesswoaqe; } $qoowakyqgwcscuss = true; umgaesggesswoaqe: qsygcycwieukkgwc: return $qoowakyqgwcscuss; } }
