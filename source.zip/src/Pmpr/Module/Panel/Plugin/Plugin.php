<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400f0d869d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin; use Pmpr\Module\Panel\Plugin\Woocommerce\Woocommerce; class Plugin extends Common { public function mameiwsayuyquoeq() { Woocommerce::symcgieuakksimmu(); } }
