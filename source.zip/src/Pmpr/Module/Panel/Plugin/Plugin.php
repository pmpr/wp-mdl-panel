<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a8141bb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Panel\Plugin; use Pmpr\Module\Panel\Plugin\Woocommerce\Woocommerce; class Plugin extends Common { public function mameiwsayuyquoeq() { Woocommerce::symcgieuakksimmu(); } }
